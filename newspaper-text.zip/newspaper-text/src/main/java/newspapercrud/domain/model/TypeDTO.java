package newspapercrud.domain.model;

public class TypeDTO {
    private String name;
    private int id;
}
