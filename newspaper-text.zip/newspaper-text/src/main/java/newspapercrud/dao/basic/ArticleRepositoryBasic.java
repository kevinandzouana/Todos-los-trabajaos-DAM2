package newspapercrud.dao.basic;

import newspapercrud.dao.ArticleRepository;
import newspapercrud.dao.model.ArticleEntity;

import java.util.List;

public class ArticleRepositoryBasic implements ArticleRepository {
    @Override
    public List<ArticleEntity> getAll() {
        return List.of();
    }

    @Override
    public ArticleEntity get(String username) {
        return null;
    }

    @Override
    public int save(ArticleEntity article) {
        return 0;
    }

    @Override
    public boolean delete(ArticleEntity article) {
        return false;
    }

    @Override
    public void update(ArticleEntity article) {

    }
}
