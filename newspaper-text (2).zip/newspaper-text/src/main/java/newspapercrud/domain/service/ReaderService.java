package newspapercrud.domain.service;

public class ReaderService {
}
