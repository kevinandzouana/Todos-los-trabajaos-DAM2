package newspapercrud.dao.model;

import newspapercrud.domain.model.TypeDTO;

public class ArticleEntity {
    private int id;
    private String name;
    private TypeDTO type;
    private int npaperId;
}
