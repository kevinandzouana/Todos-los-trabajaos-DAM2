package newspapercrud.domain.model;

public class ArticleDTO {
    private int id;
    private String name;
    private  TypeDTO type;
    private int npaperId;
    private double avgRanting;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public TypeDTO getType() {
        return type;
    }

    public void setType(TypeDTO type) {
        this.type = type;
    }

    public int getNpaperId() {
        return npaperId;
    }

    public void setNpaperId(int npaperId) {
        this.npaperId = npaperId;
    }

    public double getAvgRanting() {
        return avgRanting;
    }

    public void setAvgRanting(double avgRanting) {
        this.avgRanting = avgRanting;
    }

    public void setName(String name) {
    }
}
