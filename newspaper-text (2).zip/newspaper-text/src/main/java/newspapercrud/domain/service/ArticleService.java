package newspapercrud.domain.service;

import jakarta.inject.Inject;
import newspapercrud.dao.ArticleRepository;
import newspapercrud.dao.basic.ArticleRepositoryBasic;
import newspapercrud.dao.model.ArticleEntity;
import newspapercrud.domain.model.ArticleDTO;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ArticleService {
    private final ArticleRepository articleRepository;

    @Inject
    public ArticleService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    // Obtener todos los artículos
    public List<ArticleDTO> getAllArticles() {
        List<ArticleEntity> articles = articleRepository.getAll();
        return articles.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    // Obtener artículo por ID
    public Optional<ArticleDTO> getArticleById(int id) {
        Optional<ArticleEntity> entityOpt = articleRepository.getById(id);
        return entityOpt.map(this::toDto);
    }

    // Agregar artículo
    public ArticleDTO addArticle(ArticleDTO dto) {
        ArticleEntity entity = toEntity(dto);
        ArticleEntity saved = articleRepository.save(entity);
        return toDto(saved);
    }

    // Actualizar artículo
    public ArticleDTO updateArticle(ArticleDTO dto) {
        ArticleEntity entity = toEntity(dto);
        ArticleEntity updated = articleRepository.update(entity);
        return toDto(updated);
    }

    // Eliminar artículo
    public boolean deleteArticleById(int id) {
        return articleRepository.delete(id);
    }

    // ==========================
    // MÉTODOS DE CONVERSIÓN
    // ==========================

    private ArticleDTO toDto(ArticleEntity entity) {
        ArticleDTO dto = new ArticleDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setNpaperId(entity.getNpaperId());
        dto.setAvgRanting(entity.getAvgRanting());
        dto.setType(entity.getType()); // aquí asumo que entity.getType() devuelve un TypeDTO
        return dto;
    }

    private ArticleEntity toEntity(ArticleDTO dto) {
        ArticleEntity entity = new ArticleEntity();
        entity.setId(dto.getId());
        entity.setName(dto.getName());
        entity.setNpaperId(dto.getNpaperId());
        entity.setAvgRanting(dto.getAvgRanting());
        entity.setType(dto.getType()); // idem arriba
        return entity;
    }
}

