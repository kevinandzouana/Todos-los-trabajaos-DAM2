package newspapercrud.dao.basic;

import newspapercrud.dao.CredentialRepository;
import newspapercrud.dao.model.CredentialEntity;

import java.util.List;

public class CredentialRepositoryBasic implements CredentialRepository {
    @Override
    public List<CredentialEntity> getAll() {
        return List.of();
    }

    @Override
    public CredentialEntity get(String username) {
        return null;
    }

    @Override
    public int save(CredentialEntity credential) {
        return 0;
    }

    @Override
    public boolean delete(CredentialEntity credential) {
        return false;
    }

    @Override
    public void update(CredentialEntity credential) {

    }
}
