package newspapercrud.dao;

import newspapercrud.dao.model.ArticleEntity;
import newspapercrud.dao.model.CredentialEntity;

import java.util.List;

public interface ArticleRepository {
    List<ArticleEntity> getAll();
    ArticleEntity get(String username);
    int save(ArticleEntity article);
    boolean delete(ArticleEntity article);
    void update(ArticleEntity article);
}
