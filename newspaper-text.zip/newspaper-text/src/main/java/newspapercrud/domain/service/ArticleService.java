package newspapercrud.domain.service;

import jakarta.inject.Inject;
import newspapercrud.dao.basic.ArticleRepositoryBasic;
import newspapercrud.dao.model.ArticleEntity;
import newspapercrud.domain.model.ArticleDTO;

import java.util.List;

public class ArticleService {
    private final ArticleRepositoryBasic articleRepository;
    @Inject
    public ArticleService(ArticleRepositoryBasic articleRepository) {
        this.articleRepository = articleRepository;
    }
    public List<ArticleDTO> getAllArticles() {
        List<ArticleEntity> articles = articleRepository.getAll();
        return List.of();
    }
}
