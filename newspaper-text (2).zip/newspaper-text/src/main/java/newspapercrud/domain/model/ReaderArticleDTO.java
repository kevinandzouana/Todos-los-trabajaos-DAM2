package newspapercrud.domain.model;

public class ReaderArticleDTO {
}
