package newspapercrud.domain.service;

public class TypeService {
}
