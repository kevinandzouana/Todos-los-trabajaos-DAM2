package newspapercrud.dao.model;

public class TypeEntity {
    private int id;
    private String description;
}
